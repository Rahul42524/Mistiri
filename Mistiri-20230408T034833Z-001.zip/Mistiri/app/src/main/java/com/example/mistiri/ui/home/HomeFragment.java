package com.example.mistiri.ui.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mistiri.BannerImage.BannerImage;
import com.example.mistiri.R;
import com.example.mistiri.ReviewAndComments.ReviewAndComments;
import com.example.mistiri.Services.BasicElectricalActivity;
import com.example.mistiri.Services.BeautyParlour;
import com.example.mistiri.Services.Documents;
import com.example.mistiri.Services.HomeApplicacesActivity;
import com.example.mistiri.Services.Insurance;
import com.example.mistiri.Services.Laptop_Mobile;
import com.example.mistiri.Services.MansCare;
import com.example.mistiri.Services.News;
import com.example.mistiri.Services.PlumbingAndSanitation;
import com.example.mistiri.Services.Shifting;
import com.example.mistiri.ui.send.SendFragment;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class HomeFragment extends Fragment implements View.OnClickListener {

    //Banner
  /*  private RecyclerView mPeopleRV;
    private DatabaseReference mDatabase;
    private FirebaseRecyclerAdapter<BannerImage, HomeFragment.NewsViewHolder> mPeopleRVAdapter;


*/
    private LinearLayout plumbingAndSanitary,basicElectrical,home_applicance,shifting,laptop_mobile;
    private LinearLayout insurance,mensCare,beautyParlour,documents;

    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {



        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
/*
        // banner
        mDatabase = FirebaseDatabase.getInstance().getReference().child("Banner Image");
        mDatabase.keepSynced(true);

        mPeopleRV = (RecyclerView) root.findViewById(R.id.myRecycleView);

        DatabaseReference personsRef = FirebaseDatabase.getInstance().getReference().child("Banner Image");
        Query personsQuery = personsRef.orderByKey();

        mPeopleRV.hasFixedSize();
        mPeopleRV.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        mPeopleRV.setLayoutManager(new LinearLayoutManager(this.getActivity()));

        FirebaseRecyclerOptions personsOptions = new FirebaseRecyclerOptions.Builder<BannerImage>().setQuery(personsQuery, BannerImage.class).build();

        mPeopleRVAdapter = new FirebaseRecyclerAdapter<BannerImage, HomeFragment.NewsViewHolder>(personsOptions) {

            @Override
            protected void onBindViewHolder(@NonNull HomeFragment.NewsViewHolder holder, int position, @NonNull final BannerImage model) {

                //holder.setImage(model.getImage());
                holder.setImage(model.getImage());
               // holder


                    /*
                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(getActivity(), "Please Wait...", Toast.LENGTH_LONG).show();
                            Intent addServiceForm = new Intent(getActivity(), Book_Service_form.class);
                            startActivity(addServiceForm);

                        }
                    });


                     */
     /*       }

            @NonNull
            @Override
            public HomeFragment.NewsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

                View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.banner_row, viewGroup, false);

                HomeFragment.NewsViewHolder holder = new NewsViewHolder(view);
                //HomeFragment.NewsViewHolder holder = new SendFragment.NewsViewHolder(view);
                return holder;

            }
        };
        mPeopleRV.setAdapter(mPeopleRVAdapter);

*/
        //




        //
        plumbingAndSanitary = (LinearLayout)root.findViewById(R.id.plumbing_and_Sanitary);
        plumbingAndSanitary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage;
                addNewPage = new Intent(getActivity(),PlumbingAndSanitation.class);
                startActivity(addNewPage);
            }
        });

        basicElectrical = (LinearLayout) root.findViewById(R.id.basic_electrical);
        basicElectrical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addBasicElectrical;
                addBasicElectrical = new Intent(getActivity(), BasicElectricalActivity.class);
                startActivity(addBasicElectrical);
            }
        });

        home_applicance = (LinearLayout)root.findViewById(R.id.home_appliances);
        home_applicance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addHomeApplicances;
                addHomeApplicances = new Intent(getActivity(), HomeApplicacesActivity.class);
                startActivity(addHomeApplicances);
            }
        });

        shifting = (LinearLayout)root.findViewById(R.id.shifting);
        shifting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addshifting;
                addshifting = new Intent(getActivity(), Shifting.class);
                startActivity(addshifting);
            }
        });

        laptop_mobile = (LinearLayout)root.findViewById(R.id.laptop_mobile);
        laptop_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addLaptop;
                addLaptop = new Intent(getActivity(), Laptop_Mobile.class);
                startActivity(addLaptop);
            }
        });

        insurance = (LinearLayout)root.findViewById(R.id.insurance);
        insurance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addInsurance;
                addInsurance = new Intent(getActivity(), Insurance.class);
                startActivity(addInsurance);
            }
        });

        mensCare = (LinearLayout)root.findViewById(R.id.men_care);
        mensCare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addMenCare;
                addMenCare = new Intent(getActivity(), MansCare.class);
                startActivity(addMenCare);
            }
        });

        beautyParlour = (LinearLayout)root.findViewById(R.id.beauty_parlour);
        beautyParlour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addBeautyParalour;
                addBeautyParalour = new Intent(getActivity(), BeautyParlour.class);
                startActivity(addBeautyParalour);
            }
        });

        documents = (LinearLayout)root.findViewById(R.id.documents);
        documents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addDocuments;
                addDocuments = new Intent(getActivity(), Documents.class);
                startActivity(addDocuments);
            }
        });


        //

        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });







        return root;

    }
    //banner
/*

    @Override
    public void onStart () {
        super.onStart();
        mPeopleRVAdapter.startListening();
    }

    @Override
    public void onStop () {
        super.onStop();
        mPeopleRVAdapter.stopListening();
    }


    public class NewsViewHolder extends RecyclerView.ViewHolder {
        View mView;

        public NewsViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }

/*        public void setImage(Context ctx,String image){
            ImageView imageView = (ImageView) mView.findViewById(R.id.banner);
            Picasso.with(ctx).load(image).into(imageView);
        }

    }
    */
//




    @Override
    public void onClick(View v) {
        // implements your things

    }
}