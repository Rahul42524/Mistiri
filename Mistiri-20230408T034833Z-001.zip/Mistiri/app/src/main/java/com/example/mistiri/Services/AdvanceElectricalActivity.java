package com.example.mistiri.Services;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mistiri.R;

public class AdvanceElectricalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advance_electrical);
    }
}
