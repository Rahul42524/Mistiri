package com.example.mistiri.ui.gallery;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.mistiri.R;
import com.example.mistiri.Services.PlumbingAndSanitation;
import com.khalti.checkOut.api.Config;
import com.khalti.checkOut.api.OnCheckOutListener;
import com.khalti.utils.Constant;

import java.util.HashMap;

public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;
    private LinearLayout eSewa,khaltiButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        /*final TextView textView = root.findViewById(R.id.text_gallery);
        galleryViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        eSewa = (LinearLayout)root.findViewById(R.id.esewa);
        eSewa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage;
                addNewPage = new Intent(getActivity(), PlumbingAndSanitation.class);
                startActivity(addNewPage);
            }
        });
        khaltiButton = (LinearLayout)root.findViewById(R.id.khalti_button);
        /*khaltiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage;
                addNewPage = new Intent(getActivity(), PlumbingAndSanitation.class);
                startActivity(addNewPage);
            }
        });*/

        //

        String publicKey = Constant.pub;
        String productId = "product_id";
        String productName = "product_name";
        Long amount = 100L; // In Paisa

        Config config = new Config("Public Key", "Product ID", "Product Name", "Product Url", amount, new OnCheckOutListener() {

            @Override
            public void onSuccess(HashMap<String, Object> data) {
                Log.i("Payment confirmed", data+"");
            }

            @Override
            public void onError(String action, String message) {
                Log.i(action, message);
            }
        });


        //


        return root;
    }
}