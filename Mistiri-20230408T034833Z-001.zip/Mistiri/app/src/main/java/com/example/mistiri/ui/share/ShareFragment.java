package com.example.mistiri.ui.share;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.mistiri.LoginActivity;
import com.example.mistiri.Main2Activity;
import com.example.mistiri.R;
import com.google.firebase.auth.FirebaseAuth;

public class ShareFragment extends Fragment {

    private ShareViewModel shareViewModel;
    private TextView yes, no;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        shareViewModel =
                ViewModelProviders.of(this).get(ShareViewModel.class);
        View root = inflater.inflate(R.layout.fragment_share, container, false);
        //final TextView textView = root.findViewById(R.id.text_share);


        yes = (TextView)root.findViewById(R.id.yes);
        no = (TextView)root.findViewById(R.id.no);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Logout();
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addMainPage = new Intent(getActivity(), Main2Activity.class);
                startActivity(addMainPage);
            }
        });



     /*   shareViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        return root;
    }

    private void Logout() {
        FirebaseAuth.getInstance().signOut();
        Intent addLoginPage = new Intent(getActivity(), LoginActivity.class);
        addLoginPage.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(addLoginPage);
    }
}