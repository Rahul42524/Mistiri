package com.example.mistiri.ReviewAndComments;

public class ReviewAndComments {


    private  String editComments;
    private  float editRatingbar;
    private String ratingSaveCurrentDate;
    private String ratingId;


    public ReviewAndComments() {
    }

    public ReviewAndComments(String editComments, String ratingSaveCurrentDate,float editRatingbar, String ratingId) {
        this.editComments = editComments;
        this.editRatingbar = editRatingbar;
        this.ratingSaveCurrentDate = ratingSaveCurrentDate;
        this.ratingId = ratingId;
    }


    public String getEditComments() {
        return editComments;
    }

    public void setEditComments(String editComments) {
        this.editComments = editComments;
    }

    public float getEditRatingbar() {
        return editRatingbar;
    }

    public void setEditRatingbar(float editRatingbar) {
        this.editRatingbar = editRatingbar;
    }

    public String getRatingSaveCurrentDate() {
        return ratingSaveCurrentDate;
    }

    public void setRatingSaveCurrentDate(String ratingSaveCurrentDate) {
        this.ratingSaveCurrentDate = ratingSaveCurrentDate;
    }

    public String getRatingId() {
        return ratingId;
    }

    public void setRatingId(String ratingId) {
        this.ratingId = ratingId;
    }
}
