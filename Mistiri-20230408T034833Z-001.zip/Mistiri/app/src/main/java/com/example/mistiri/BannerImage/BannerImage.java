package com.example.mistiri.BannerImage;

import android.widget.ImageView;

public class BannerImage {

    private int image;

    public BannerImage() {
    }

    public BannerImage(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
