package com.example.mistiri.Services;

public class News {


    private  String title;
    private  String charge;
    private  String image;
    private  String avl;

    public News(String title, String charge, String image, String avl) {
        this.title = title;
        this.charge = charge;
        this.image = image;
        this.avl = avl;
    }

    public News()
    {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAvl() {
        return avl;
    }

    public void setAvl(String avl) {
        this.avl = avl;
    }
}
