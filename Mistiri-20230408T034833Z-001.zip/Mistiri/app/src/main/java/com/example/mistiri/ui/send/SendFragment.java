package com.example.mistiri.ui.send;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mistiri.Book_Service_form;
import com.example.mistiri.Main2Activity;
import com.example.mistiri.R;
import com.example.mistiri.ReviewAndComments.ReviewActivity;
import com.example.mistiri.ReviewAndComments.ReviewAndComments;
import com.example.mistiri.Services.BasicElectricalActivity;
import com.example.mistiri.Services.News;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class SendFragment extends Fragment {

    private SendViewModel galleryViewModel;
    private FloatingActionButton fab1;

    private RecyclerView mPeopleRV;
    private DatabaseReference mDatabase;
    private FirebaseRecyclerAdapter<ReviewAndComments, SendFragment.NewsViewHolder> mPeopleRVAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(SendViewModel.class);
        View root = inflater.inflate(R.layout.fragment_send, container, false);


        fab1 = (FloatingActionButton) root.findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Main2Activity.this, "call button", Toast.LENGTH_SHORT).show();

                Intent addReviewPage = new Intent(getActivity(), ReviewActivity.class);
                startActivity(addReviewPage);
                //
            }
        });

//
        if (isConnected(SendFragment.this)) {
            //Toast.makeText(BlogsActivity.this,"Welcome", Toast.LENGTH_SHORT).show();
            //setContentView(R.layout.activity_blogs);*/
            //"News" here will reflect what you have called your database in Firebase.
            mDatabase = FirebaseDatabase.getInstance().getReference().child("Review and Comments");
            mDatabase.keepSynced(true);

            mPeopleRV = (RecyclerView) root.findViewById(R.id.myRecycleView);

            DatabaseReference personsRef = FirebaseDatabase.getInstance().getReference().child("Review and Comments");
            Query personsQuery = personsRef.orderByKey();

            mPeopleRV.hasFixedSize();
            mPeopleRV.setLayoutManager(new LinearLayoutManager(this.getActivity()));
            mPeopleRV.setLayoutManager(new LinearLayoutManager(this.getActivity()));

            FirebaseRecyclerOptions personsOptions = new FirebaseRecyclerOptions.Builder<ReviewAndComments>().setQuery(personsQuery, ReviewAndComments.class).build();

            mPeopleRVAdapter = new FirebaseRecyclerAdapter<ReviewAndComments, SendFragment.NewsViewHolder>(personsOptions) {

                @Override
                protected void onBindViewHolder(@NonNull SendFragment.NewsViewHolder holder, int position, @NonNull final ReviewAndComments model) {

                    holder.setComments(model.getEditComments());
                    holder.setRatingbar(model.getEditRatingbar());


                    /*
                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(getActivity(), "Please Wait...", Toast.LENGTH_LONG).show();
                            Intent addServiceForm = new Intent(getActivity(), Book_Service_form.class);
                            startActivity(addServiceForm);

                        }
                    });


                     */
                }

                @NonNull
                @Override
                public SendFragment.NewsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

                    View view = LayoutInflater.from(viewGroup.getContext())
                            .inflate(R.layout.review_row, viewGroup, false);


                    SendFragment.NewsViewHolder holder = new SendFragment.NewsViewHolder(view);
                    return holder;

                }
            };
            mPeopleRV.setAdapter(mPeopleRVAdapter);
        } else {
            buildDialog(SendFragment.this).show();
        }
        return root;
    }



    @Override
    public void onStart () {
        super.onStart();
        mPeopleRVAdapter.startListening();
    }

    @Override
    public void onStop () {
        super.onStop();
        mPeopleRVAdapter.stopListening();
    }


    public static class NewsViewHolder extends RecyclerView.ViewHolder {
        View mView;

        public NewsViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setComments(String comments){
            TextView comment = (TextView) mView.findViewById(R.id.com1);
            comment.setText(comments);
        }

        public void setRatingbar(float ratingbar){

            RatingBar rating = (RatingBar) mView.findViewById(R.id.rat1);
            //rating.setRating(Float.parseFloat(ratingbar));
            // .child("rating").setValue(String.valueOf(rating));
            rating.setRating(ratingbar);
            //rating.setRating(Float.parseFloat(String.valueOf(ratingbar)));
        }


    }


    public boolean isConnected (SendFragment context){

        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if (netinfo != null && netinfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if ((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else return false;
        } else
            return false;
    }

    public AlertDialog.Builder buildDialog (SendFragment c){

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("No Internet Connection");
        builder.setMessage("Please check your Mobile Data or wifi");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });

        return builder;
    }


//


}
