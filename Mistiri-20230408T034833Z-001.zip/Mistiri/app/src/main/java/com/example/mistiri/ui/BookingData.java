package com.example.mistiri.ui;

public class BookingData {

    private String title, name, phone, landmark, fulladdress;

    public BookingData()
    {

    }

    public BookingData(String title, String name, String phone, String landmark, String fulladdress) {
        this.title = title;
        this.name = name;
        this.phone = phone;
        this.landmark = landmark;
        this.fulladdress = fulladdress;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getFulladdress() {
        return fulladdress;
    }

    public void setFulladdress(String fulladdress) {
        this.fulladdress = fulladdress;
    }
}
