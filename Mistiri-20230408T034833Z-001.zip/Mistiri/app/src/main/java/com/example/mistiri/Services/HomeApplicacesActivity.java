package com.example.mistiri.Services;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.mistiri.R;
import com.example.mistiri.Services.HomeApplicances.AcRepairAndInstillation;
import com.example.mistiri.Services.HomeApplicances.InverterUpsOffline;
import com.example.mistiri.Services.HomeApplicances.KitchenHoodServicing;
import com.example.mistiri.Services.HomeApplicances.RefrigratorAndWashingMachine;
import com.example.mistiri.Services.HomeApplicances.TreadmillRepair;
import com.example.mistiri.Services.HomeApplicances.TvRepair;
import com.example.mistiri.Services.HomeApplicances.WaterMotor_ElectricGayser;

public class HomeApplicacesActivity extends AppCompatActivity {

    LinearLayout acRepair,waterMotor,Tv,inverter,refrigerator,kitchenHood,treadMill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_applicaces);

        acRepair = (LinearLayout) findViewById(R.id.ac_repair_and_inst);
        waterMotor = (LinearLayout) findViewById(R.id.water_motor);
        Tv = (LinearLayout) findViewById(R.id.tv_repair);
        inverter = (LinearLayout) findViewById(R.id.inverter);
        refrigerator = (LinearLayout) findViewById(R.id.refrigerator);
        kitchenHood = (LinearLayout) findViewById(R.id.kitchen);
        treadMill = (LinearLayout) findViewById(R.id.treadmill);


        acRepair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, AcRepairAndInstillation.class);
                startActivity(addNewPage);
            }
        });

        waterMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, WaterMotor_ElectricGayser.class);
                startActivity(addNewPage);
            }
        });

        Tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, TvRepair.class);
                startActivity(addNewPage);
            }
        });
        inverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, InverterUpsOffline.class);
                startActivity(addNewPage);
            }
        });

        refrigerator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, RefrigratorAndWashingMachine.class);
                startActivity(addNewPage);
            }
        });

        kitchenHood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, KitchenHoodServicing.class);
                startActivity(addNewPage);
            }
        });

        treadMill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addNewPage = new Intent(HomeApplicacesActivity.this, TreadmillRepair.class);
                startActivity(addNewPage);
            }
        });

    }
}
