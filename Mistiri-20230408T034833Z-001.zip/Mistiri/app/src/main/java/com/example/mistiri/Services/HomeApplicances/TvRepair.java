package com.example.mistiri.Services.HomeApplicances;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mistiri.Book_Service_form;
import com.example.mistiri.R;
import com.example.mistiri.Services.News;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class TvRepair extends AppCompatActivity {

    private RecyclerView mPeopleRV;
    private DatabaseReference mDatabase;
    private FirebaseRecyclerAdapter<News, TvRepair.NewsViewHolder> mPeopleRVAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv_repair);

        if (isConnected(TvRepair.this)) {
            //Toast.makeText(BlogsActivity.this,"Welcome", Toast.LENGTH_SHORT).show();
            //setContentView(R.layout.activity_blogs);*/
            //"News" here will reflect what you have called your database in Firebase.
            mDatabase = FirebaseDatabase.getInstance().getReference("Servicing").child("Basic Electrical Service");
            mDatabase.keepSynced(true);

            mPeopleRV = (RecyclerView) findViewById(R.id.myRecycleView);

            DatabaseReference personsRef = FirebaseDatabase.getInstance().getReference("Servicing").child("Basic Electrical Service");
            Query personsQuery = personsRef.orderByKey();

            mPeopleRV.hasFixedSize();
            mPeopleRV.setLayoutManager(new LinearLayoutManager(this));

            FirebaseRecyclerOptions personsOptions = new FirebaseRecyclerOptions.Builder<News>().setQuery(personsQuery, News.class).build();

            mPeopleRVAdapter = new FirebaseRecyclerAdapter<News, TvRepair.NewsViewHolder>(personsOptions) {

                @Override
                protected void onBindViewHolder(@NonNull TvRepair.NewsViewHolder holder, int position, @NonNull final News model) {

                    holder.setTitle(model.getTitle());
                    holder.setCharge(model.getCharge());
                    holder.setAvl(model.getAvl());
                    holder.setImage(getBaseContext(), model.getImage());

                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            /*Toast.makeText(BasicElectricalActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
                            Intent addServiceForm = new Intent(BasicElectricalActivity.this, Book_Service_form.class);
                            startActivity(addServiceForm);
*/

                            // sen
                            final String title = model.getTitle().toString();
                            Intent intent = new Intent(getApplicationContext(), Book_Service_form.class);
                            intent.putExtra("title", title);
                            startActivity(intent);


                        }
                    });
                }

                @NonNull
                @Override
                public TvRepair.NewsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

                /*View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.blogs_row1, viewGroup, false);

                return null;*/
                    //return new MainActivity().NewsViewHolder(view);
                    return new TvRepair.NewsViewHolder(LayoutInflater.from(viewGroup.getContext())
                            .inflate(R.layout.service_row, viewGroup, false));


                }
            };
            mPeopleRV.setAdapter(mPeopleRVAdapter);
        } else
        {
            buildDialog(TvRepair.this).show();
        }
    }

    @Override
    public void onStart () {
        super.onStart();
        mPeopleRVAdapter.startListening();
    }

    @Override
    public void onStop () {
        super.onStop();
        mPeopleRVAdapter.stopListening();
    }


    public static class NewsViewHolder extends RecyclerView.ViewHolder {
        public View mView;

        public NewsViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setTitle(String title) {
            TextView post_title = (TextView) mView.findViewById(R.id.service_title);
            post_title.setText(title);
        }


        public void setCharge(String charge) {
            TextView service_charge = (TextView) mView.findViewById(R.id.service_charge);
            service_charge.setText(charge);
        }

        public void setImage(Context ctx, String image) {
            ImageView post_image = (ImageView) mView.findViewById(R.id.service_image);
            Picasso.with(ctx).load(image).into(post_image);
        }

        public void setAvl(String avl) {
            TextView post_avl = (TextView) mView.findViewById(R.id.availablity);
            post_avl.setText(avl);
        }
    }


    public boolean isConnected (Context context){

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if (netinfo != null && netinfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if ((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else return false;
        } else
            return false;
    }

    public AlertDialog.Builder buildDialog (Context c){

        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("No Internet Connection");
        builder.setMessage("Please check your Mobile Data or wifi");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });

        return builder;
    }



}
